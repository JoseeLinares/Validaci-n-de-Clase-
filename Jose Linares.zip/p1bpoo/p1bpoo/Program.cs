﻿
using p1bpoo.MisClases;
using System;
using p1bpoo.MisClases;

namespace p1bpoo
{
    class Program
    {
        static void Main(string[] args)
        {
            Chofer Juan = new Chofer("Juan", 30, "M");
            Chofer Jaime = new Chofer("Jaime", 25, "M");
            Moto motito = new Moto(2020, "Rojo", "Yamaha");

            motito.AsignarPiloto(Jaime);
            motito.AsignarPiloto(Juan);
            motito.Encender();
            motito.acelerar(10);
            motito.Acrobacia();

        }
    }
}




