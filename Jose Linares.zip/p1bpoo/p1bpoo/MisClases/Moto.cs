﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p1bpoo.MisClases
{
    internal class Moto : Vehiculo
    {
        public Moto(int anio, string elColor, string elModelo) : base(anio, elColor, elModelo)
        {
            tiposLicenciaAceptados = new List<string> { "M" };
            VelocidadMaxima = 234;
            CapacidadTanque = 15;
            ConsumoCombustible = 0.5;
        }
        public void InformacionVehiculo()
        {
            base.InformacionVehiculo();
        }

        public void Encender()
        {
            base.Encender();
        }
        public override void acelerar(int cuanto)
        {
            base.acelerar(cuanto);
            
        }

        public override void frenar()
        {
            base.frenar();
        }

        public void AsignarPiloto(Chofer elPiloto)
        {
            base.AsignarPiloto(elPiloto);
        }

        public void Acrobacia()
        {
            if (estadoVehiculo == 2)
            {
                Console.WriteLine("Haciendo acrobacias");
            }
            else if (estadoVehiculo == 1)
            {
                Console.WriteLine("No se puede hacer acrobacias si el vehiculo no esta en movimiento");
            }
            else
            {
                Console.WriteLine("No se puede hacer acrobacias si el vehiculo no esta encendido");
            }
        }
    }
}
