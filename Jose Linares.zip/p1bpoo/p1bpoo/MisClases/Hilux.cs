﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p1bpoo.MisClases
{
    internal class Hilux : Vehiculo
    {
        public Hilux(int anio, string elColor, string elModelo) : base(anio, elColor, elModelo)
        {
            tiposLicenciaAceptados = new List<string> {"B"};
        }
        public override void acelerar(int cuanto)
        {
            base.acelerar(cuanto);
        }
    }
}
